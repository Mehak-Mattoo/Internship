package com.myproject.java;

public class AddOne { 
	
	class Node {    
        int data;    
        Node next;    
            
        public Node(int data) {    
            this.data = data;    
            this.next = null;    }     }    
     
    public static Node head = null;    
    public Node tail = null;    
           
    public void addNode(int data) {    
        
        Node newNode = new Node(data);    
                 
        if(head == null) {             
            head = newNode;    
            tail = newNode; }   
           
        else {                
            tail.next = newNode;       
            tail = newNode;    }}
       
        
   
    
    public static  Node AddOne(Node head) {
    	
    	Node new_Node= reverseNode(head);
    	Node currNode = new_Node;
    	Node previousNode= null;
    	int carry =0;
    	
    	while(currNode!=null) {
    		int sum=0;
    		
    		if(previousNode== null) { // we are the first value
    			sum= currNode.data+1;} // add 1
    		
    		else {
    			sum= currNode.data+carry;}// else add along the carry 
    		
    		carry= sum/10;  // get carry
    		currNode.data= sum%10;
    		
    		previousNode= currNode;  // move previous ahead
    		currNode= currNode.next;} // and current as well
    		 
    	
    	
    	
    	return reverseNode(currNode);  // reverse the ans in the end
    	
    
    
    
    }
    
    public static Node reverseNode(Node head) {  // reverse list to traverse only only one time in linked list
    	
    	 Node currNode= head;
         Node prev = null;
         
         
    	while (currNode!= null) {
    		Node tempNode= currNode.next;
    		prev= currNode;
    		currNode= tempNode;}

    	return prev;    }
    
    static void printList(Node node)
    {
        while (node != null)
        {
            System.out.print(node.data);
            node = node.next;
        }
        System.out.println();
    }
       


public static void main(String[] args) {

	  AddOne sList = new  AddOne();    
      
      sList.addNode(1);    
      sList.addNode(2);    
      sList.addNode(3);    
      sList.addNode(2);   
      
    sList.AddOne(sList.head);
    
    sList.printList(sList.head);
      

        
   
     
}
}
