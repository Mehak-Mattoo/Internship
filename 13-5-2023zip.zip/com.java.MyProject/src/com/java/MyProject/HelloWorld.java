package com.java.MyProject;

public class HelloWorld {
public static void main(String[] args) {
	
createHelloWorld();	
}

public static void createHelloWorld() { // calls printHelloWorld

	printHelloWorld();
}

public static void printHelloWorld() { // prints hello world
	
	
System.out.println("Hello World");	}

}
