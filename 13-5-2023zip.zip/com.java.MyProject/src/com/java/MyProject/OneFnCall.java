package com.java.MyProject;



public class OneFnCall {
public static void main(String[] args) {

	System.out.print("calls: 1, value:"); // prints the sum
	IdenticalFn();
	
}

public static void Fn() { // calls identical Fn
	int a=1,b=2,c=3;
	System.out.println(a+b+c);
	IdenticalFn();  // called once

}
public static void IdenticalFn() {  // returns the same value as Fn
	int a=1,b=2,c=3;
	System.out.println(a+b+c);
}
}
