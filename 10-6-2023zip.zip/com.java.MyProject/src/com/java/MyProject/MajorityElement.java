package com.java.MyProject;
import java.util.Arrays;



public class MajorityElement {
public static void main(String[] args) {
	
	int A[] = {3,6,4,3,1,3} ;
	int size= A.length;
	
	System.out.println(majorityElement(A, size ));
}	
	
    static int majorityElement(int a[] , int size) {
	
    	 int max= a.length/2;
    		int count=0;
    		
    		
    			if(size==1) { // if there is only one element, return it
    			return a[0];}
    			
    	Arrays.sort(a); // sorting

    	for (int i = 0; i < size-1; i++) {
    	    
    	    if(a[i]!=a[i+1]) {  // if adjacent elements are not same, keep count as 0
    	          count=0;}
    		
    		if(a[i]== a[i+1]) { // if they are same, increment count
    			count++;	}
    		
    		if(count> max-1) { // if count becomes larger than max , return it
    			return a[i];}  	}
    		

    		return -1;}		}

	
	


