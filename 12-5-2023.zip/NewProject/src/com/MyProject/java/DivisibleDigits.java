package com.MyProject.java;

public class DivisibleDigits {
public static void main(String[] args) {
	
	
	int num= 1248;
	int count=0;
	int duplicate= num;  // keeping a copy of num
	
	while(num>0) {  // check digits of num that are divisible by its digits
		int digit= num%10;

		if(duplicate%digit==0) {
			count++;}
		
		num/=10;}
	
	System.out.println(count);
}
}
