package com.MyProject.java;


public class PrimeSubtractOperation {
public static void main(String[] args) {
	
		
	int nums[]= {5,8,3};
	
	System.out.println(primeSubOperation(nums));  }

public static boolean primeSubOperation(int[] nums) {
	
	 int curr = 0;
	 
     for(int i=0;i<nums.length;i++){
         int p = nums[i]-1;
         
         if(curr>=nums[i]) {         	 
        	 return false;}
         
         
       while(!isPrime(p)) {  // loop until prime is found
    	   p--; }
       
       while(curr>=nums[i]-p){   // if curr is smaller than current element- prime
           p--;
           while(!isPrime(p)) {
        	   p--; }}
       
       
       curr = nums[i]-p; }// set curr value to the difference
     return true;}


 public static boolean isPrime(int x){    // getting prime number
     if(x==1) return false;
     if(x==2 || x==3) return true;
 
     
     for(int i=2;i<=x/2;i++){
         if(x%i==0) { 
        	 return false;  }}
     
     return true;
 }
}