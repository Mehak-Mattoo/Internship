package com.java.MyProject;

public class Float {
public static void main(String[] args) {
	
	
	int a=67,b=7;
	 float result = a/b;
	
	    System.out.print(result+" ");
        System.out.printf("%.3f",+ result);// formatted to display result upto 3 decimal places.

}
}
