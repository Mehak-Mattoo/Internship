package com.java.MyProject;

import java.util.Scanner;

public class NumberAndString {
public static void main(String[] args) {
	
int N=78;
String S="Love";
	
	printIntString(S, N);
}	 static void printIntString(String S,int N){
	
	System.out.println("The input string is "+ S +"\nThe input number is "+ N); // input printed in tow lines
}
}
