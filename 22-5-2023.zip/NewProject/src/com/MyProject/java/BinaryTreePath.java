package com.MyProject.java;
import java.util.*;

class Node{
	
	Node left, right;
     int  data;

public Node(int data) {
	 this.data= data;  }
}
class BinaryTree{
	static Node root;

static void add(int data) {

	Node newNode= new Node(data);
	
	if(root== null) {
		root= newNode;  }
	
	else {
		Node focusNode= root;
		Node parent;
		
		while(true) {
			parent= focusNode;
			
			if(data< focusNode.data) { //  smaller data will be at left side
				focusNode= focusNode.left;  // changing focus to left side
				if(focusNode== null) {
					parent.left= newNode;
					return;   }}
				
				else {
					focusNode= focusNode.right;  // changing focus to right side
					if(focusNode== null) {
						parent.right= newNode;
						return;  }}
		
	
}}}


public static List<String> InOrder(Node focusNode) {

	List <String> list = new ArrayList<>();
	
	return helper(focusNode, list,"");
	
}


private static List<String> helper(Node focusNode, List<String> list, String s) {
	
	if(focusNode.right== null&& focusNode.left== null) {  // when a leaf node is encountered
		s+= focusNode.data;  // add its data into list
		list.add(s); }
	
	
	s+= focusNode.data +",";	  // add a comma
	
	if(focusNode.left!= null) {	// recur down left tree if it is not null
	helper(focusNode.left, list, s); }
	
	if(focusNode.right != null) { // recur down right tree if it is not null
	helper(focusNode.right, list, s);}
	
	return list;
	
	
}}

public class BinaryTreePath {
	public static void main(String[] args) {
		
	
	BinaryTree tree= new BinaryTree()	;

	tree.root=new Node(4);
	tree.root.left = new Node(7);
	tree.root.right= new Node(9);
	tree.root.left.left = new Node(13);
	tree.root.left.right= new Node(20);

	
	List <String> list = new ArrayList<>();
	list = tree.InOrder(tree.root);
	
	for(String s: list) {
		System.out.println(s);
	}
	
	
}
}