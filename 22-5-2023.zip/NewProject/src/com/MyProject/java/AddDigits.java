package com.MyProject.java;

public class AddDigits {
	public static void main(String[] args) {
		
		
	int num= 38;
	
	System.out.println(addDigits(num));
		
	}

	
	 public static int addDigits(int num) {
		 
		 int sum=0;
		 int x = num;
		 
		 while(x>9) {  // loop until x remains bigger than 9
			 sum+= x %10;			 			 
			 x/=10;
			 
			 if(x <10) {  // if x becomes a single digit num return it
				 x+= sum;
				 sum= 0;} }
		
		 return x;}
}
