package com.myproject.java;

class Node {
    int data;
    Node left, right;

    public Node(int data) {
        this.data = data;
        left = right = null;
    }
}

class BinaryTreeToCDLL {
    Node root;
    Node head; // Head of the CDLL

    // Helper function to concatenate two CDLLs
    public Node concatenate(Node leftList, Node rightList) {
        // If either of the lists is empty, return the other list
        if (leftList == null) {
            return rightList;
        }
        if (rightList == null) {
            return leftList;
        }

        // Store the last nodes of both lists
        Node leftLast = leftList.left;
        Node rightLast = rightList.left;

        // Connect the last node of the left list with the first node of the right list
        leftLast.right = rightList;
        rightList.left = leftLast;

        // Connect the last node of the right list with the head of the left list
        leftList.left = rightLast;
        rightLast.right = leftList;

        return leftList;
    }

    // Function to convert a binary tree to CDLL
    public Node binaryTreeToCDLL(Node root) {
        if (root == null) {
            return null;
        }

        // Convert the left and right subtrees to CDLL
        Node left = binaryTreeToCDLL(root.left);
        Node right = binaryTreeToCDLL(root.right);

        // Make root a circular doubly linked list of length 1
        root.left = root.right = root;

        // Concatenate the left subtree with the root
        Node result = concatenate(left, root);

        // Concatenate the result with the right subtree
        result = concatenate(result, right);

        return result;
    }

    // Function to print the CDLL
    public void printCDLL(Node head) {
        if (head == null) {
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.right;
        } while (current != head);
    }
}

public class CDLL {
    public static void main(String[] args) {
        BinaryTreeToCDLL tree = new BinaryTreeToCDLL();

        // Create a binary tree
        tree.root = new Node(10);
        tree.root.left = new Node(12);
        tree.root.right = new Node(15);
        tree.root.left.left = new Node(25);
        tree.root.left.right = new Node(30);
        tree.root.right.left = new Node(36);

        // Convert the binary tree to CDLL
        Node head = tree.binaryTreeToCDLL(tree.root);

        // Print the CDLL
        System.out.println("Circular Doubly Linked List:");
        tree.printCDLL(head);
    }
}

