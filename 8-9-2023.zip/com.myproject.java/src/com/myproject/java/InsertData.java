package com.myproject.java;
class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

class Solution {
    public ListNode insertIntoSortedLinkedList(ListNode head, int data) {
        ListNode newNode = new ListNode(data);

        // If the list is empty or the data is smaller than head's value
        if (head == null || data < head.val) {
            newNode.next = head;
            return newNode;
        }

        ListNode current = head;

        // Find the correct position to insert the new node
        while (current.next != null && data > current.next.val) {
            current = current.next;
        }

        // Insert the new node
        newNode.next = current.next;
        current.next = newNode;

        return head;
    }

    public void printLinkedList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class InsertData {
    public static void main(String[] args) {
       
        ListNode head = new ListNode(1);
        ListNode second = new ListNode(2);
        ListNode third = new ListNode(4);
        ListNode fourth = new ListNode(5);
        head.next = second;
        second.next = third;
        third.next = fourth;

        int data = 3;

        Solution solution = new Solution();
        System.out.println("Original Linked List:");
        solution.printLinkedList(head);

        // Insert the data into the sorted linked list
        ListNode updatedHead = solution.insertIntoSortedLinkedList(head, data);

        System.out.println("Updated Linked List:");
        solution.printLinkedList(updatedHead);
    }
}
