package com.java.MyProject;

public class IsVowelPresent {
	public static void main(String[] args) {
		
		
String s1= "Hello";
	
	
System.out.println(	CheckVowel(s1));	
	
	
	}

	private static boolean CheckVowel(String s1) {
		
for (int i = 0; i < s1.length(); i++) {
if(s1.charAt(i)== 'a' || s1.charAt(i)== 'e'|| s1.charAt(i)== 'i'|| s1.charAt(i)== 'o'|| s1.charAt(i)== 'u'){

	// if any character of the string has a,e,i,o,u then, return true
	
	return true;}}

			return false;  // otherwise false
		}
		
		
	}