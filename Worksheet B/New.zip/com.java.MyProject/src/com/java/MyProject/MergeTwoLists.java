package com.java.MyProject;

class Node {
	
    int data;
    Node next;
    Node(int d) {
    	
        data = d;
        next = null;}}

 
class MergeTwoLists {
    Node head;
 

    public void addToTheLast(Node node)  {
    	
        if (head == null) {
            head = node;
        }
        else {
            Node temp = head;
            while (temp.next != null)
                temp = temp.next;
            temp.next = node;
        }
    }
    
    static Node sortedMerge(Node listA, Node listB)
    {
 
        Node dummyNode = new Node(0);
        Node result = dummyNode;
        
        while (true) {
 

            if (listA == null) {
                result.next = listB;          
                break;          }   // if any list becomes null, use the other one
            
            if (listB == null) {
                result.next = listA;
                break;            }
 
 
            if (listA.data <= listB.data) {
                result.next = listA;     // if listA has lesser data , then point tail next to
                listA = listA.next;           // to list A
            }
            else {
                result.next = listB;  // vice versa
                listB = listB.next;
            }
 
            result = result.next;
        }
        return dummyNode.next;  }
 
    
    void printList()
    {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;}    }
    
    
 

    public static void main(String args[])  {
  
        MergeTwoLists llist1 = new MergeTwoLists();
        MergeTwoLists llist2 = new MergeTwoLists();
 
    
        llist1.addToTheLast(new Node(5));
        llist1.addToTheLast(new Node(6));
        llist1.addToTheLast(new Node(18));
 
      
        llist2.addToTheLast(new Node(2));
        llist2.addToTheLast(new Node(3));
        llist2.addToTheLast(new Node(15));
 
        llist1.head =sortedMerge(llist1.head, llist2.head);
        System.out.println("Merged Linked List:");
        llist1.printList();
    }
}
 


