package com.java.MyProject;
import java.util.*;
import java.util.Map.Entry;


	
	
class BNode{
	
	BNode left, right;
    int  data;
    int d;
  
	
public BNode(int data) {
	 this.data= data;  }}


class Solution{

	 private int d;

	public Solution(int d) {
		this.d = d; }

	public static BNode root;
	
	
	public void BottomView(BNode root) {
		
		
		int d=0;	 // distance	
		
		if (root == null) {
            return;}
	
	Queue<BNode> q= new LinkedList<BNode>(); 
	Map<Integer, Integer> map= new HashMap<>();  // map stores distance of nodes from root
	
	root.d= d;
	q.add(root);
	
		
	while(!q.isEmpty()) {
		
		BNode tempNode= q.poll();
		d= tempNode.d;
		map.put(d, tempNode.data);
			
		
		 if (tempNode.left != null) {	  // while going left, distance --		 
			 tempNode.left.d= d-1;			 
           q.add( tempNode.left); }   // adding left node

		 
         if (tempNode.right != null) {       // while going right, distance ++	 	 
        	 tempNode.right.d= d+1;       	 
        	 q.add( tempNode.right);  } }
	
	
	Set<Entry<Integer, Integer>> set = map.entrySet();

    Iterator<Entry<Integer, Integer>> iterator = set.iterator();

    while (iterator.hasNext())
    {
        Map.Entry<Integer, Integer> me = iterator.next();
        System.out.print(me.getValue()+" ");
    }}}
	



public class BottomView {
	
	public static void main(String[] args) {
		
		
		Solution tree= new Solution(0);

		
		
		tree.root = new BNode(2);
        tree.root.left = new BNode(18);
        tree.root.right = new BNode(22);
        tree.root.left.left = new BNode(15);
        tree.root.left.right = new BNode(3);
        tree.root.right.left = new BNode(4);
        tree.root.right.right = new BNode(35);
        tree.root.left.right.left = new BNode(10);
        tree.root.left.right.right = new BNode(14);
		
		tree.BottomView(tree.root);
		
	}
	

}
