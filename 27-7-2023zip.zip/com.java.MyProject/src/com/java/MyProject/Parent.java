package com.java.MyProject;

public class Parent{

	void show(int p) {
	p=9;	}

	void print(int q) {
	q=3;}
	
}


	class Child extends Parent{
	    @Override
	    void show(int p) { System.out.print(p+" "); }
	    
	    @Override
	    void print(int q) {
	        System.out.println(q*q+"");// returns the square of input 
	    }
	    
	 
	    
}
