package com.java.MyProject;


public class Interface {
public static void main(String[] args) {
	testClass t= new testClass();
	
	t.display(8);
	
}

}

interface in1{
	static void  display(int p) {
		p=9;
	}
}
class testClass implements in1
{
    public void display(int k) {   
      
         int count1,count2=0;
         for(int j=2;j<=k;j++) {// iterate upto k
               count1 =0;
                for (int i = 2; i <= j; i++) {
                    if (j % i == 0) {// if remainder ==0 increase count1
                        count1++;            }       }
                
                if (count1 == 1) {
                   count2++; }          }
        
         System.out.println(count2);       }
    }