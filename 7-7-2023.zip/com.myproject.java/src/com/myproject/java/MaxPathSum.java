package com.myproject.java;
import java.util.*;

class Node{
	
	Node left, right;
     int  data;

public Node(int data) {
	 this.data= data;  }
}
class BinaryTree{
	static Node root;

static void add(int data) {

	Node newNode= new Node(data);
	
	if(root== null) {
		root= newNode;  }
	
	else {
		Node focusNode= root;
		Node parent;
		
		while(true) {
			parent= focusNode;
			
			if(data< focusNode.data) { //  smaller data will be at left side
				focusNode= focusNode.left;  // changing focus to left side
				if(focusNode== null) {
					parent.left= newNode;
					return;   }}
				
				else {
					focusNode= focusNode.right;  // changing focus to right side
					if(focusNode== null) {
						parent.right= newNode;
						return;  }}
		
	
}}}

class Res {
    public int val;
}

int findMaxUtil(Node node, Res res)
{

    if (node == null)
        return 0;

    // l and r store maximum path sum going through left and right child
    int l = findMaxUtil(node.left, res);
    int r = findMaxUtil(node.right, res);

    int max_single = Math.max(
        Math.max(l, r) + node.data, node.data);

 
    int max_top
        = Math.max(max_single, l + r + node.data);

    // Store the Maximum Result.
    res.val = Math.max(res.val, max_top);

    return max_single;
}

int findMaxSum() { 
	
	return findMaxSum(root); }


int findMaxSum(Node node){
    Res res = new Res();
    res.val = Integer.MIN_VALUE;

 
    findMaxUtil(node, res);    // Compute and return result
    return res.val;}
}

public class MaxPathSum  {
public static void main(String[] args) {
BinaryTree tree= new BinaryTree()	;

tree.root=new Node(4);
tree.root.left = new Node(7);
tree.root.right= new Node(9);
tree.root.left.left = new Node(13);
tree.root.left.right= new Node(20);
tree.root.right.left= new Node(23);
tree.root.right.right= new Node(70);



System.out.println( tree.findMaxSum());
	
}
}
