package com.myproject.java;

public class MergeSortedArr {
public static void main(String[] args) {
	
	 int arr1[] = {2, 3, 6, 8,0,0,0};
	 int arr2[] = {3, 5, 10};
	
	int n= 4;
	int m= 3;
	
	merge(arr1, arr2, n, m);
	
	for(int i:arr1) {
		System.out.print(i+" ");
	}
	
}
static int [] merge (int arr1[], int arr2[], int n, int m) {
	
	
	int pointer1= n-1;  //pointing at at end of arr1 instead of 0
	int pointer2= m-1;// at end of arr2
	int i= n+m-1; // at end of arr1 with 0s
	
	while(pointer1>=0&& pointer2>=0) { // loop until array does not go out of bounds
		
		if(arr1[pointer1]> arr2[pointer2]) {// if arr1 has higher element than arr2
			arr1[i]= arr1[pointer1]; // then at 0s put that value
			i--;
			pointer1--;}
		
		else {
			arr1[i]= arr2[pointer2]; // vice versa
			i--;
			pointer2--;}}
	
	
		
		while(pointer1>=0) {  // when both arrays have diff. length, then one array will go out of bounds earlier
			arr1[i]= arr1[pointer1];// then as arrays are already sorted,  put elements in first array
			i--;
			pointer1--;}
		
		while(pointer2>=0) {
			arr1[i]= arr2[pointer2];
			i--;
			pointer2--;}
	
	return arr1;
	
}

}
