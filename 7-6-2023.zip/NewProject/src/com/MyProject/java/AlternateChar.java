package com.MyProject.java;

public class AlternateChar {
public static void main(String[] args) {
	
	String s= "Love";
	
	String ans="";
	
	for (int i = 0; i < s.length(); i+=2) {  // put the alternate char in and string  and print the output
		ans+= s.charAt(i);}
	
	System.out.println(ans);
	
}
}
