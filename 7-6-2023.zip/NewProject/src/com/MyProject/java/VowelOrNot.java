package com.MyProject.java;

public class VowelOrNot {
public static void main(String[] args) {
	
	
	char c= 'Z';
	
	if(c=='a' || c=='A'|| c=='e'|| c=='E'||c=='I' ||c=='i'|| c== 'o'||c =='O' ||c=='U'|| c=='u') { // check if char c is a vowel or not
		System.out.println("Yes");}
	
	else {
		System.out.println("No");
	}
	
}
}
