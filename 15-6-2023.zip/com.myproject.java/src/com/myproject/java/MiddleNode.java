package com.myproject.java;


public class MiddleNode {

	class Node {    
        int data;    
        Node next;    
            
        public Node(int data) {    
            this.data = data;    
            this.next = null;    }     }    
     
    public static Node head = null;    
    public Node tail = null;    
           
    public void addNode(int data) {    
        
        Node newNode = new Node(data);    
                 
        if(head == null) {             
            head = newNode;    
            tail = newNode; }   
           
        else {                
            tail.next = newNode;       
            tail = newNode;    }}
       
        
    
    public static int MiddleElement(Node head) {
    	
    	Node slowNode= head;
    	Node fastNode =head;
    	
    	while(fastNode!= null && fastNode.next!= null ) { // until fast pointer does not become null
    		fastNode= fastNode.next.next; // fast pointer moves two places
    		slowNode= slowNode.next; }  // slow pointer moves 1 space
    		    	
    		
    	return slowNode.data; } // slow pointer will always point to the middle node


    
    
    
    
    
 public static void main(String[] args) {
	 
	 
	 MiddleNode sList= new MiddleNode();
	 
	 
	  sList.addNode(1);    
      sList.addNode(2);    
      sList.addNode(3);    
      sList.addNode(4);    
      sList.addNode(5);  
      sList.addNode(6);
   
     System.out.println(sList.MiddleElement(head));
}   
    
}



