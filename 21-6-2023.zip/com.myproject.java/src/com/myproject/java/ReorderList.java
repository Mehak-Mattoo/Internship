package com.myproject.java;
public class ReorderList {
	
	
	class Node{    
        int data;    
        Node next;    
            
        public Node(int data) {    
            this.data = data;    
            this.next = null;    }     }    
     
    public static Node head = null;    
    public Node tail = null;    
           
    public void addNode(int data) {    
        
        Node newNode = new Node(data);    
                 
        if(head == null) {             
            head = newNode;    
            tail = newNode; }   
           
        else {                
            tail.next = newNode;       
            tail = newNode;    }}
       
        
    public void display() {    
       
        Node current = head;    
            
        if(head == null) {    
            System.out.println("List is empty");    
            return;    }
           
        while(current != null) {    
           
            System.out.print(current.data + " ");    
            current = current.next;   }} 

  
  
  public void reOrderList(Node head) {
	  
	  if(head== null || head.next == null) {
		  return;}
	  
	  Node l1= head; // head of first half of list
	
	  Node fastPointer = head;
	  Node slowPointer = head;
	  Node previous= null;
	  
	  
	  // splitting list into 2 halves
	  while(fastPointer != null&& fastPointer.next != null) {
		  previous= slowPointer;    // becomes tail of first half of list
		  fastPointer = fastPointer.next.next;  // tail of scond half
		slowPointer = slowPointer.next; } // becomes head of second half of list
			
	  previous.next= null; // separated
	  
	  Node l2= reverse(slowPointer);// reversing the second half
	
	  mergeTwoLists(l1, l2);  // merging two lists together
	  
	  
	  }

  public Node reverse(Node head) {
		
		Node previous = null;
		Node current = head;
		
		if(head== null) {
			return head;}
		
		
		while(current!= null) {
			Node tempNode = current.next;
			current.next= previous;  // here the next pointer will start pointing to the previous element
			previous= current;      // hence changing the direction of traversal
			current= tempNode; }
					
		return previous;}  
  
  
  public static void mergeTwoLists(Node list1, Node list2) {		
			

		while(list1 != null ) {	 
			Node l1_next= list1.next;
			Node l2_next= list2.next;
						
			
			list1.next = list2;
			
			if(l1_next== null) {// when list 1 is fully traversed
				break;}
			
			list2.next= l1_next; // merge the head of second half to tail of first
			list1= l1_next;
			list2= l2_next;		}		}
	  
     
	  
  public static void main(String[] args) {    
            
       ReorderList sList = new  ReorderList();    
               
        sList.addNode(1);    
        sList.addNode(2);    
        sList.addNode(3);    
        sList.addNode(4);    
            
      sList.reOrderList(head);
      sList.display();
        

       
} 

}
