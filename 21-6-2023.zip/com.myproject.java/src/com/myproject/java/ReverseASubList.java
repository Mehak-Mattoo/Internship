package com.myproject.java;


public class ReverseASubList {

	static Node head;

	static class Node {

		int data;
		Node next;

		Node(int d)
		{
			data = d;
			next = null;
		}
	}

	
	static Node reverseBetween(Node head, int m, int n)
	{

	
		Node curr = head, prev = null; // prev points to the node before mth node
		int i;
		for (i = 1; i < m; i++) {
			prev = curr;
			curr = curr.next;
		}
	
		Node rtail = curr; 	//stores the pointer to the head of the reversed linkedlist
		
		Node rhead = null; //  stores the pointer to the tail of the reversed linkedlist
		
		while (i <= n) { // Now reverse the linked list from m to n nodes
			Node next = curr.next;
			curr.next = rhead;
			rhead = curr;
			curr = next;
			i++;
		}
		// if prev is not null it means that some of the
		// nodes exits before m ( or if m!=1)
		if (prev != null)
			prev.next = rhead;
		else
			head = rhead;
		// at this point curr will point to the next of nth
		// node where we will connect the tail of the
		// reversed linked list
		rtail.next = curr;
		// at the end return the new head.
		return head;
	}

	// prints content of double linked list
	void printList(Node node)
	{
		while (node != null) {
			System.out.print(node.data + " ");
			node = node.next;
		}
	}

	// Driver Code
	public static void main(String[] args)
	{
		ReverseASubList list = new ReverseASubList();
		list.head = new Node(1);
		list.head.next = new Node(4);
		list.head.next.next = new Node(10);
		list.head.next.next.next = new Node(8);
		list.head.next.next.next.next = new Node(5);
		list.head.next.next.next.next.next = new Node(60);
	
	
		
		reverseBetween(head, 3, 5);
		list.printList(head);
	}
}

