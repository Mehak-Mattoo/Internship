package com.MyProject.java;

public class Fraction {
public static void main(String[] args) {
	
	
	
	String expression = "-1/2+1/2";
	System.out.println(fractionAddition(expression));
	
}


    public static String fractionAddition(String exp) {
    	
    	
        int[][] fractions = new int[10][2];
        int fractCount = 0;
        int sign = 1,i=0, n = exp.length();
        if(exp.charAt(i)=='-'){
            sign = -1;
            i = 1;
        }
        else{
            sign = 1;
            i =0;
        }
        int num = 0,denom =0;
        
        //parsing
        while(i<n){ //Find common mulitple by multiplying all denominators
            num =0;
            while(exp.charAt(i)!= '/'){
                num = num*10 + (exp.charAt(i)-'0');
                i++;
            }

            //div symbol 
            i++;

            denom = 0;
            while(i<n && (exp.charAt(i)!='-' && exp.charAt(i)!='+' )){
                denom = denom*10 + (exp.charAt(i)-'0');
                i++;
            }
            fractions[fractCount++]= new int[]{sign*num, denom};
            if(i<n){
                if(exp.charAt(i)=='-'){
                    sign = -1;
                }
                else{
                    sign = +1;
                }
                i++;
            }else{
                break;
            }
        }

        int commonMultiple = 1;
        for( i=0;i<fractCount;i++){
            commonMultiple *= fractions[i][1];
        }

 //normalize numerators by changing denominator with common multiple.
        int numSum =0;
        for( i=0;i<fractCount;i++){
            fractions[i][0] = fractions[i][0] * (commonMultiple/fractions[i][1]);
            numSum+= fractions[i][0];
        }
        
        
//Make them irreducible fraction by dividing with 2, 3, 5, 7 
        int[] primes = new int[]{2,3,5,7};
        boolean isReduced = true;
        num = numSum;
        denom = commonMultiple;
        while(isReduced){
            isReduced = false;
            for(int prime:primes){
                while(num%prime==0 && denom%prime ==0){
                    isReduced = true;
                    num/= prime;
                    denom/=prime;
                }
            }
        }
        return ""+num+"/"+denom;
    }   

}
