package com.MyProject.java;
import java.util.*;


public class LongestHarmoniousSubsequence {
public static void main(String[] args) {

	
	int  nums[] = {1,3,2,2,5,2,3,7};
	
	System.out.println(findLHS(nums));
}

public static int findLHS(int[] nums) {
	
Arrays.sort(nums);
int left=0, right=1, result=0;


while(right<nums.length) { // move inside the nums.length
	int diff= nums[right]- nums[left];  // get the difference
	
	if(diff==1) { 
		result= Math.max(result, right-left+1);} 
	
	if(diff<=1) { // if diff is less than 1, move the window to the right
		right++;}
	
	else { // vice -versa
		left++;}}


return result;



}
}
