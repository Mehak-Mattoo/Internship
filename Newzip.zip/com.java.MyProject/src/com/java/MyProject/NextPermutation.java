package com.java.MyProject;


public class NextPermutation {
public static void main(String[] args) {
	
	
	int arr[]= {2,1,3,4};
	
	
	NextPermutation(arr);
	 for (int i : arr) {
	      System.out.print(i + " ");
	    }
}

private static void NextPermutation(int[] arr) {
	
	int index1= 0;
	int index2= 0;
	

	if(arr== null|| arr.length<=1){
		return;
	}

	
	for (int i = arr.length-2; i>=0; i--) {  // traverse from the end to get the first min value
		if(arr[i] < arr[i+1]) {
			index1= i;   // when found, store it and break
			break;}}
	
	if(index1==0) {  // if not found, then it means that the array was in descending order
		reverse(arr, 0, arr.length-1);	}  // then simply return the ascending order
	
	
	else {   // when index1 was found
	for (int i = arr.length-1; i>index1; i--) { // traverse again from end, to get a number higher
		if(arr[i]> arr[index1]) {  // than index1
			index2 = i;   // store its index and break
			break;   }}
		
	swap(arr, index1, index2);   // simply swap to get the next greater permutation
	
	reverse(arr, index1 +1, arr.length-1);  // then reverse the elements after index1
	
	}}
	
	static void	swap (int []arr , int index1, int index2) {
		
	int temp = arr[index1];
	arr[index1]= arr[index2];
	arr[index2]= temp;}
	

	public static void reverse(int []arr , int index1, int index2) {
		while(index1< index2) {
		swap(arr, index1, index2);
		index1++;
		index2--; }
	
	
	

	
}
}
