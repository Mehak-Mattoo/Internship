package com.myproject.java;
import java.util.*;

public class FindMax {
public static void main(String[] args) {
	
	
int arr []= {2,3,5,7,8,2,4};
int n= arr.length;
	
	System.out.println(findMaximum(arr, n));
	
}
static int findMaximum(int[] arr, int n) {
    
    Arrays.sort(arr); // sort the arr and return the last element
    return arr[n-1];
}}
