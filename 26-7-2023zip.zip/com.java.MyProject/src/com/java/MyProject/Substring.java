package com.java.MyProject;

public class Substring {
public static void main(String[] args) {
String S = "cdbkdub";
int L = 0 , R = 5	;

System.out.println(javaSub(S, L, R));
	
}

static String javaSub(String S, int L, int R) {
	
	String anString="";
	anString= S.substring(L,R);// returns a substring of a string
	return anString;
}
}
