package com.java.MyProject;

public class cls1 {

static class cls2 extends cls1 {// inheritance

    void mul(int p,int q) {
        System.out.println(p*q);   }
    
    
    void task(int p,int q){
        int sum = (p*p) + (q*q);
        System.out.println(sum);
    }
}

public static void main(String[] args) {
	
	cls2 c= new cls2();
	c.mul(2, 2);
	c.task(7, 2);
	
}
}
