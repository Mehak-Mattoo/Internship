package com.myproject.java;

public class CoinChange {
public static void main(String[] args) {
	
	int coins[]= {1,2,3};
	int amount= 3;
	
	System.out.println(solution(coins, amount));
}

public static long solution(int coins[], int amount) {
	
    long ans[][] = new long[coins.length+1][amount+1];
    
    
    for(int i=0;i<coins.length+1;i++){  // first fill 1 row and column with 0
        ans[i][0]=1;
    }
    for(int j=0;j<amount+1;j++){
        ans[0][j]=0;
    }
    for(int i=1;i<=coins.length;i++){
        for(int j=1;j<= amount;j++){
        	
        	
   if(coins[i-1]<=j){ // if current coin is smaller than current amount
    ans[i][j] = ans[i-1][j]+ ans[i][j-coins[i-1]]; }  // then add the upper row value with current amount with
                                                     //coin - upper row value
     else{
      ans[i][j]=ans[i-1][j];}}   } // if current coin is larger current value, then copy the upper cell value
   
    
    return ans[coins.length][amount]; // last cell hold the ans

}}

