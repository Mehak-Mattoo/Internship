package com.myproject.java;

public class PeakElement {
public static void main(String[] args) {
	
	int arr[]= {7,6,9,51,5};
	
	System.out.println( peakElement(arr, 0));
}

public static int peakElement(int[] arr,int n){	
	
	
    int max=arr[0];
    int index=0;
    for(int i = 0;i<n;i++){
        if(arr[i]>max){  // if current element is bigger than max, then update max value
            max=arr[i];
            index=i; // and get its index
        }    
    }return index;
 }
}


