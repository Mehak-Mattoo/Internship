package com.java.MyProject;

public class Count1 {
public static void main(String[] args) {

	int n=9;
	System.out.println(countDigitOne(n));
}


public static int countDigitOne(int n) { //To count the number of "1"s divide n by 10^i
	                                    // and then multiply the result by i. 
	                                   
    int count = 0;
for (long i = 1; i <= n; i *= 10) {
long divider = i * 10;
count += (n / divider) * i + Math.min(Math.max(n % divider - i + 1, 0), i); //add the number of "1"s in the remaining part of n 
                                                                           // Math.min &max avoid counting "1"s not present in the remaining part of n.
}
return count;

}

}
