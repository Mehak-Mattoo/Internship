package com.Myproject.java;
import java.util.*;



class BSTNode{

	BSTNode right;
	BSTNode left;
	int data;
	
	public BSTNode(int data) {		
	this.data= data;	}}


class BST{
	
static	BSTNode rootNode;

	public void insert(int data) {
		rootNode = insert(rootNode, data);	}
	

public	static BSTNode insert(BSTNode root ,int data) {
		
		if(root == null) {
			 root = new BSTNode(data);}
		
		else if(data < root.data) {
		root.left = insert(root.left, data);	} // inserting at right subtree 
		
		else if (data> root.data){
			root.right = insert(root.right, data); }  // inserting at left subtree
				
		return root;	}




public static String serialize(BSTNode root)
{
    if (root == null) {
        return null;
    }
    Stack<BSTNode> s = new Stack<>();
    s.push(root);

    List<String> l = new ArrayList<>();
    while (!s.isEmpty()) {
        BSTNode temp = s.pop();

        // If current node is NULL, store n as null
        if (temp == null) {
            l.add("n");     }
      
        else {

            // Else, store current node
            // and recur for its children
            l.add("" + temp.data);
            s.push(temp.right);
            s.push(temp.left);
        }
    }
    return String.join(",", l);
}

static int i;

public static BSTNode deserialize(String data)
{
    if (data == null)
        return null;
    
    i = 0;
    String[] arr = data.split(",");  // split the elements in array when , is found
    return helper(arr);
}

public static BSTNode helper(String[] arr)
{
    if (arr[i].equals("n"))
        return null;

  
    BSTNode root  = new BSTNode(Integer.parseInt(arr[i]));  // first element is the root
   
    i++;
    root.left = helper(arr);  // recurr down to left and right children
    i++;
    root.right = helper(arr);
    return root;
}



static void inorder(BSTNode root){ 
	
    if (root != null) {
        inorder(root.left);
        System.out.print(root.data + " ");
        inorder(root.right);   }}}
	


public class SerializeDeserialize {
	public static void main(String[] args) {
	
		BST tree= new BST()	;

		tree.insert(5);
		tree.insert(3);
		tree.insert(7);
		tree.insert(1);
		
		
		
		String serialized = tree.serialize(tree.rootNode);
	        System.out.println("Serialized tree:");
	        System.out.println(serialized);
	      	 

	        BSTNode ans = tree.deserialize(serialized);
	 
	        System.out.println("\nDeserialized tree: ");
	       tree.inorder(ans);	    }		}



