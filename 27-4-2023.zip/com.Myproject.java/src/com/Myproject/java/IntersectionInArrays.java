package com.Myproject.java;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class IntersectionInArrays {
public static void main(String[] args) {
	
	
	int[] nums1= {5,7,9,3,1};
	int[] nums2= {1,9,8,8,2};
	

int	[]  ans = intersection(nums1, nums2);

for (int i : ans) {
	System.err.print(i +" , ");
}
}

public static int[] intersection(int[] nums1, int[] nums2) {
	
	List<Integer> list = new ArrayList<>();	// using array list because size of array is not given
	 
	 
	 HashSet<Integer> set= new HashSet<>();
	 
	 for (int i = 0; i < nums1.length; i++) {  // add all elements of num1
		set.add(nums1[i]);	}
	 
	 
	 
	 for (int i = 0; i < nums2.length; i++) { // if any element of num2 matches, then add it into the list 
		if(set.contains(nums2[i])) {
			list.add(nums2[i]);  
			set.remove(nums2[i]); } }  // and remove from the set , to avoid duplicacy in list
	 
	 int []ans= new int[list.size()];
	 
	 for (int i = 0; i <list.size(); i++) {  // add all elements of list in array
		 ans[i]= list.get(i);}
		
	
			
		return ans;
	
	 
}
}
