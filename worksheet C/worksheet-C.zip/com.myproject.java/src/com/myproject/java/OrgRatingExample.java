package com.myproject.java;

import java.util.Scanner;

class Organization {
    private int rating;

    // Constructor
    public Organization(int rating) {
        this.rating = rating;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}

public class OrgRatingExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the rating for the organization: ");
        int rating = scanner.nextInt();

        Organization org = new Organization(rating);

        System.out.println("Organization rating: " + org.getRating());

       
    }
}
