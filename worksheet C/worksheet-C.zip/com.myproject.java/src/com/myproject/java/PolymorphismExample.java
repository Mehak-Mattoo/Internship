package com.myproject.java;

//Superclass Shape
abstract class Shape {
 abstract void draw();
}

//Subclass Square
class Square extends Shape {

 void draw() {
     System.out.println("Drawing a square");
 }
}

//Subclass Circle
class Circle extends Shape {

 void draw() {
     System.out.println("Drawing a circle");
 }
}

public class PolymorphismExample {
 public static void main(String[] args) {
     // Creating an array of Shape objects
     Shape[] shapes = new Shape[2];
     shapes[0] = new Square();
     shapes[1] = new Circle();

     // Polymorphic method calls
     for (Shape shape : shapes) {
         shape.draw();
     }
 }
}