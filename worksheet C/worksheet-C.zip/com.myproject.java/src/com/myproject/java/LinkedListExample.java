package com.myproject.java;

class ListNode {
    int data;
    ListNode next;

    public ListNode(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    ListNode head;

    public LinkedList() {
        this.head = null;
    }

    public void insert(int data) { // inserts data
        ListNode newNode = new ListNode(data);

        if (head == null) {
            head = newNode;
        } else {
            ListNode current = head;
            while (current.next != null) { // keep on inserting data as long as next is null
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void display() {   // display data
        ListNode current = head;

        if (current == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        System.out.print("Linked list: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
       
    }
}

public class LinkedListExample {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        list.display();
    }
}
