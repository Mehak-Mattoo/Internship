package com.myproject.java;


	class Animal {
	    void eat() {
	        System.out.println("Animal is eating...");
	    }
	}

	// Subclass 1 inheriting from Animal
	class Dog extends Animal {
	    void bark() {
	        System.out.println("Dog is barking...");
	    }
	}

	// Subclass 2 inheriting from Animal
	class Cat extends Animal {
	    void meow() {
	        System.out.println("Cat is meowing...");
	    }
	}

	// Subclass 3 inheriting from Dog and Cat
	class Tiger extends Dog {
	    void run() {
	        System.out.println("Tiger is running...");
	    }
	}

	// Subclass 4 inheriting from Cat
	class Lion extends Cat {
	    void roar() {
	        System.out.println("Lion is roaring...");
	    }
	}

	public class InheritanceExample {
	    public static void main(String[] args) {
	        Tiger tiger = new Tiger();
	        tiger.eat();  // Inherited from Animal
	        tiger.bark(); // Inherited from Dog
	        tiger.run();  // Defined in Tiger class

	        Lion lion = new Lion();
	        lion.eat();   // Inherited from Animal
	        lion.meow();  // Inherited from Cat
	        lion.roar();  // Defined in Lion class
	    }
	
}
