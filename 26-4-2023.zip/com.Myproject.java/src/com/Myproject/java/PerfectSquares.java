package com.Myproject.java;
import java.util.*;



public class PerfectSquares {
	public static void main(String[] args) {
		
		
		int num=19;
		
System.out.println(  PerfectSquares(num));	}
	

	private static int PerfectSquares(int n) {
		
		 List<Integer> list = new ArrayList<>();
		 
		 int current=1;
		 
		 while(Math.pow(current, 2)<= n) {  //list gets filled by squares of numbers
			list.add((int) Math.pow(current++,2 )); } 
		 
		 
	        int[] arr = new int[n + 1];  // a dp array gets filled integer max value
	        Arrays.fill(arr, Integer.MAX_VALUE);
	        
	        arr[0]=0;  // base case
	        
for (int i = 1; i < n+1; i++) {
	for(int j=0; j<list.size()&& list.get(j)<= i; j++) {
		arr[i] = Math.min(arr[i], 1 + arr[i-list.get(j)]); }} // array gets filled with min of existing value  
			                                             // or value present in the list
	      
return arr[n];}  // last value of array has the ans
			 
			 

}
