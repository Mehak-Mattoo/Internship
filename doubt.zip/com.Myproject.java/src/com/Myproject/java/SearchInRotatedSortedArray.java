package com.Myproject.java;

public class SearchInRotatedSortedArray {
public static void main(String[] args) {
	
	
	int[] arr= {4,5,6,7,0,1,2};
	int target= 0;
	
System.out.println(	Solution(arr,target, arr.length));
}

private static int Solution(int[] arr, int target,int length) {
	
	int low = 0;
	int high = length-1;
	
	
	while(low<=high) {
		
		int mid=  low+ (high-low) /2;
		
		
		if(arr[mid]==target) {
			return mid; }
		
		if(arr[low]<= arr[mid]) {// checking if left part is sorted or not
			
		if(target <= arr[mid] && target>= arr[low]) { // then key must be bigger than low and smaller than mid,
				high= mid-1;}  //then  key will be present at left side
			
		else {
			low= mid+1;}}
		
		else { // if left part is not sorted then right part must be sorted

			if(target >= arr[mid] && target<= arr[high]) {//then key must be bigger than mid and smaller than high,
				low= mid+ 1;	}   //then only key will be present at right side
			else {
				high= mid-1;}}}
		
			
		return -1;
	
	
	
}
}
