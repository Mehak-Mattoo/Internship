package com.MyProject.java;

public class ToLowerCase {
public static void main(String[] args) {
	
	String s= "MJHFcd";
	
	System.out.println(s.toLowerCase()); // this method converts string to lower case
}
}
