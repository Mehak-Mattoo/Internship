package com.MyProject.java;

public class Avg {
public static void main(String[] args) {
	
	
	int arr[]=  {2,4}; 
	double sum=0;
	
	for (int i = 0; i < arr.length; i++) {
		sum+=i; } //storing sum
	
    System.out.println(String.format("%.2f",sum/arr.length));  // getting formatted avg upto 2 decmal places 
		
}
}
