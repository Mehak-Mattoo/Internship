package com.myproject.java;

public class EqualSum {
public static void main(String[] args) {
	
	int arr[]= {1,3,5,4,3};
	
System.out.println(equilibrium(arr, arr.length));	
}
static String equilibrium(int arr[], int n) {
	
	int sum=0, sum2=0;
	
	for (int i = 0; i <n; i++) {// get all the sum first
		sum+= arr[i];}
	 
	for (int i = 0; i <n; i++) { // sequentially add the sum
		sum2+= arr[i];
		
		if(sum-sum2== sum2-arr[i]) { // check if sum becomes equal at some point
			return "Yes"; }}
	
	
	return "No";  }
}