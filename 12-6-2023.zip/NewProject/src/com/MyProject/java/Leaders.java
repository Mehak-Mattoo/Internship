package com.MyProject.java;

public class Leaders {
public static void main(String[] args) {
	
	
	
	
	int[] arr= {16,17,0,2,8,9,1};
	int leader= arr[arr.length-1];
	

System.out.print("Leaders in this array: "+leader +" , ");	//because the rightmost element will always be a leader
	for (int i = arr.length-1; i>-1; i--) {
	
		if(arr[i]>leader) {
		leader= arr[i]; 
		System.out.print(leader+ ", ");
		
}			
	}	
}}