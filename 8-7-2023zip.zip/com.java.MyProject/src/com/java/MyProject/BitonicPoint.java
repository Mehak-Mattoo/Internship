package com.java.MyProject;

import java.util.Arrays;

public class BitonicPoint {
public static void main(String[] args) {
	
	int arr[] = {1,15,25,45,42,21,17,12,11};
	
	Arrays.sort(arr);
	System.out.println(arr[arr.length-1]);
}
}
