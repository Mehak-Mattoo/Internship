package com.java.MyProject;
import java.util.*;

public class CountAnagrams {
public static void main(String[] args) {
	
	  String text = "forxxorfxdofr";
      String word = "for";
      System.out.print(countAnagrams(text, word));
}

static boolean araAnagram(String s1, String s2){

char[] ch1 = s1.toCharArray();  // converting strings to char arrays
char[] ch2 = s2.toCharArray();


Arrays.sort(ch1);
Arrays.sort(ch2);


if (Arrays.equals(ch1, ch2)) { // Check if they are equal
return true;}

else {
return false;}}


static int countAnagrams(String text, String word){
	
int N = text.length();
int n = word.length();


int ans = 0;

for (int i = 0; i <= N - n; i++) {

String s = text.substring(i, i + n);


if (araAnagram(word, s)) // Check if the word and substring are anagram of each other.
ans++; }

return ans;}}


