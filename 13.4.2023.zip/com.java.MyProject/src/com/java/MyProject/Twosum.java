package com.java.MyProject;
import java.util.*;

public class Twosum {
public static void main(String[] args) {
	
	int nums[]= {2,7,11,15};
	int target=9;
	
	int ans[]=twoSum(nums, target);
	
	System.out.println("Indexes that make up the target: ");
	for (int i : ans) {
		System.out.print(i+" , ");	}
	
	
} 

public static int[] twoSum(int[] nums, int target) {
    

	int ans[]= new int[2];

	HashMap <Integer, Integer> map = new HashMap<>();// making a hashmap to store values with their indices

	for (int i = 0; i < nums.length; i++) {
 
	if(map.containsKey(target- nums[i])) {  // if map has this value, then ans found	                                       
  ans[0]= i;
  ans[1]= map.get(target- nums[i]);
  return ans; }

	map.put(nums[i], i); }// if value not found, then put the element with its index
	  
return ans;
		
	}
}
