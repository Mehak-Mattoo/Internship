package com.java.MyProject;
import java.util.*;

public class HappyNumber {
	public static void main(String[] args) {
		
		
		int n= 89;
	System.out.println(	isHappy(n));}
	
public static boolean isHappy(int n) {	   
	
	HashSet<Integer> set= new HashSet();  // creating a set to avoid dupliate numbers that indicate loops
	while (n != 1) {
		if (!set.contains(n))  // if set does not have the num, then add
			set.add(n);
		else {               // if it does contain, then it is not a happy number
			return false;}

		int sum = 0;
		while (n != 0) {
			sum += (n % 10) * (n % 10);  
			n = n / 10;  // getting num shorter
		}
		n = sum;  // replacing n with sum
	}

	return true;}}


