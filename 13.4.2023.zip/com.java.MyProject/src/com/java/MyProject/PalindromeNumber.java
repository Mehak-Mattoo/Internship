package com.java.MyProject;

public class PalindromeNumber {
public static void main(String[] args) {
	
	int x= 989;
	System.out.println(isPalindrome(x));
	
}
public static boolean isPalindrome(int x) {
String s = String.valueOf(x); // converting int into string

int i = 0;                  // taking two pointers i= start of string and j at the end of string
int j = s.length() - 1;

  while(i <= j) {             // loop until they meet
      if(s.charAt(i) != s.charAt(j))  // if character at i is not equal j, then x is not a palindrome
          return false;
      i++;                        // move i pointer ahead
      j--;                }  // move j pointer back

return true;  

}
}

