package com.myproject.java;

class SNode {
    int data;
    Node next;

    public SNode(int data) {
        this.data = data;
        this.next = null;
    }
}

class List {
    Node head;

    public List() {
        this.head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public void deleteNode(int position) {
        if (head == null) {
            return;
        }

        Node temp = head;

        // If the head node needs to be deleted
        if (position == 0) {
            head = temp.next;
            return;
        }

        // Find the previous node of the node to be deleted
        for (int i = 0; temp != null && i < position - 1; i++) {
            temp = temp.next;
        }

        // If position is more than the number of nodes
        if (temp == null || temp.next == null) {
            return;
        }

        // Node temp->next is the node to be deleted
        // Store pointer to the next of the node to be deleted
        Node nextNode = temp.next.next;

        // Unlink the deleted node from the list
        temp.next = nextNode;
    }

    public void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class DeleteNode {
    public static void main(String[] args) {
        List list = new List();
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);

        System.out.print("Original linked list: ");
        list.display();

        int positionToDelete = 2;
        list.deleteNode(positionToDelete);

        System.out.print("Linked list after deleting node at position " + positionToDelete + ": ");
        list.display();
    }
}

