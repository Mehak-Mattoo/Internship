package com.myproject.java;


class Node {
    int data;
    Node next;
 
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
 
class LinkedList {
    Node head;
 
    public LinkedList() {
        this.head = null;
    }
 
    public void insert(int data) {
        Node newNode = new Node(data);
 
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }
 
    public void addOne() {
        Node curr = head;
        Node lastNotNine = null;
 
        // Traverse the list to find the last node that is not 9
        while (curr.next != null) {
            if (curr.data != 9) {
                lastNotNine = curr;
            }
            curr = curr.next;
        }
 
        // If the last node is not 9, increment its value by 1
        if (curr.data != 9) {
            curr.data++;
        } else {
            // If the last node is 9, set it to 0 and increment the last node that is not 9 by 1
            if (lastNotNine == null) {
                lastNotNine = new Node(0);
                lastNotNine.next = head;
                head = lastNotNine;
            }
            lastNotNine.data++;
 
            // Set all the nodes after lastNotNine to 0
            curr = lastNotNine.next;
            while (curr != null) {
                curr.data = 0;
                curr = curr.next;
            }
        }
    }
 
    public void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}
 
public class Add1 {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insert(9);
        list.insert(0);
        list.insert(9);
 
        System.out.print("Original number: ");
        list.display();
 
        list.addOne();
 
        System.out.print("After adding 1: ");
        list.display();
    }
}
