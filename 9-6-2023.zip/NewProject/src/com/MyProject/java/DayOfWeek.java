package com.MyProject.java;
import java.time.*;
import java.util.*;




public class DayOfWeek {
public static void main(String[] args) {
	
	int day = 9, month = 6, year = 2023;
	
	System.out.println(dayOfTheWeek(year, month, day));}



public static String dayOfTheWeek(int year, int month, int day) {
	
    List<String> days = Arrays.asList("SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY");  // list storing dayss of week
    Calendar cal = Calendar.getInstance();
    cal.set(year, month-1, day);    // gets the date from input value
        
    int p = cal.get(Calendar.DAY_OF_WEEK); // gets the day from date
    
    String s = days.get(p-1);  // gets the day from list
    
    return s;
}}
