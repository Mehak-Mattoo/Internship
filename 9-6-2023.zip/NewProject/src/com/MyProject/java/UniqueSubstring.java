package com.MyProject.java;

import java.util.HashSet;

public class UniqueSubstring {
public static void main(String[] args) {
	
	
	String input= "abcd"; 

	
	HashSet<String> set = new HashSet<>(); // set to store unique values
	
	for(int x = 0; x < input.length(); x++){ // store substrings in ans
        String ans = "";
        for(int y =x; y < input.length();y++){
            ans+=input.charAt(y);
            set.add(ans); // insert into set
            
 } }
	
System.out.println(set.size());	
 
}
}
