package com.java.MyProject;
import java.util.*;

public class Combinations {
	 public static void main(String[] args) {
	    
	      
	        int n = 5;
	        int k = 3;
	        ans = makeCombi(n, k);  }
	 

	 static Vector<Vector<Integer>> ans = new Vector<Vector<Integer>>();
	    static Vector<Integer> list = new Vector<Integer>();
	       
	    static void makeCombiUtil(int n, int left, int k)   {
	       
	        // Pushing this vector to a vector of vector
	        if (k == 0) {
	            ans.add(list);
	            for(int i = 0; i < list.size(); i++) {
	                System.out.print(list.get(i) + " ");   }
	            System.out.println();
	            return; }
	  
	       
	        for (int i = left; i <= n; ++i)   {
	            list.add(i);
	            makeCombiUtil(n, i + 1, k - 1);  // increaments
	  
	      list.remove(list.size() - 1); }}// removes the last inserted element to avoid duplicates
	  
	   
	    static Vector<Vector<Integer>> makeCombi(int n, int k)  {  //prints combination
	    
	        makeCombiUtil(n, 1, k);
	        return ans; }
	    
	     
	   
	}