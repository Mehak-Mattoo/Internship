package com.java.MyProject;
import java.util.*;


public class GenerateParanthesis {
public static void main(String[] args) {
	
int n=3;

List<String> res = new ArrayList<>();
 res = generateParenthesis(n);

 for( String s: res) {
	 System.out.println(s);}

}

 public static List<String> generateParenthesis(int n) {
    List<String> res = new ArrayList<>();
    
    if (n == 0) {
        return res;
    }
    
    backtrack(n, n, new String(), res);  // fn call
    return res;
}

private static void backtrack(int left, int right, String s, List<String> res) {

	
    if (right < left) {
        return;}
	
    if (left < 0 || right < 0) {
        return;   }
    
    if (left == 0 && right == 0) { // when they are all used
        res.add(s);
        return; }
	
	//put left
    backtrack(left - 1, right, s + "(", res);
	//put right
    backtrack(left, right - 1, s + ")", res);
}

}
