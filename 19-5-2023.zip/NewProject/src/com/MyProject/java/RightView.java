package com.MyProject.java;
import java.util.*;


class BNode{
	
	BNode left, right;
     int  data;

public BNode(int data) {
	 this.data= data;  }}

class LView{
	public static BNode root;
	
	public void LeftView () {
		
		Queue<BNode> queue= new LinkedList<BNode>();  // using queue because of fifo approach
        
		queue.add(root);
		
		while (!queue.isEmpty()) {
			int size = queue.size();
		
			for (int i = 0; i < size; i++) {
							
			 BNode	tempNode= queue.poll();  // removing the head of queue
			
			if(i== size-1) {/* because the left most element is always at the first (for right view simply 
			              put i==size-1 as the right most element will always be at the end */
			System.out.print(tempNode.data+ " , ");}
			
			 if (tempNode.left != null) {
	             queue.add(tempNode.left); }   // adding left node

         if (tempNode.right != null) {
	             queue.add(tempNode.right);  } } }  // adding right node
	}}


public class RightView {
public static void main(String[] args) {
	
	LView tree = new LView();
	
	tree.root=new BNode(1);
	tree.root.left = new BNode(2);
	tree.root.right= new BNode(3);
	tree.root.left.left = new BNode(13);
	tree.root.left.right= new BNode(5);
	tree.root.right.left= new BNode(23);
	tree.root.right.right= new BNode(4);
	
	System.out.println("Right- view of the tree:");
	tree.LeftView();
	
	
}
}

