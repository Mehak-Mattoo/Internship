package com.myproject.java;
import java.util.*;

public class WaveArr {
public static void main(String[] args) {
			
		int arr[]= {10, 90, 49, 2, 1, 5, 23};

		
		MaximumCombos(arr, arr.length); 
	for(int i: arr) {
		System.out.print(i+" "); }}


	private static int[] MaximumCombos(int[] arr, int length) {
		
		Arrays.sort(arr);
			
		for (int i = 0; i < length-1; i+=2) {// here elements must be in :arr[i]> arr[i+1]< arr[i+2]
			
		swap(arr, i,i+1);  }
		return arr;}  // swap elements to achieve it

	static void swap(int [] arr, int index1, int index2) {
		
		int temp = arr[index1];
		arr[index1]= arr[index2];
		arr[index2]= temp;

	}}
