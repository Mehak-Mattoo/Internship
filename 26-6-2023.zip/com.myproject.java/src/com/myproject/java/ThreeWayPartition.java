package com.myproject.java;

public class ThreeWayPartition {
public static void main(String[] args) {
	
	int arr[]= {2,0,2,1,1,0};
	
	DutchNationalFlagAlgo(arr, 0,1);

	
	for(int i: arr) {
	System.out.println(i);}}



private static void DutchNationalFlagAlgo(int[] arr, int a, int b) {
	
	int low,high,mid;            
	                              
	low= 0;                       
	mid= 0;                       
	high= arr.length-1;
	
	while(mid<= high){
		if(arr[mid]<a) {    // if num lesser than a is found, 
			
			swap(arr, mid, low); //swap low with mid so that all num lesser than a are at the left
			
			low++;
			mid++; }
		
		else if (arr[mid]>=a && arr[mid]<=b) {
			
			mid++;                     //  just move the mid
			
		}else if (arr[mid]>b) {
			swap(arr, high, mid);  // if largest num is found then, swap mid with high as they must be found at the right
			
			high--;}}
	
	
	
	
}

private static int swap(int arr[], int i, int j) {
	
	int temp = arr[i];
	arr[i]= arr[j];
	arr[j]= temp;
	
	return arr[i];}

}


