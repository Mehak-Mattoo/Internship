package com.MyProject.java;
import java.util.*;


class Node{
	
	Node left, right;
     int  data;

public Node(int data) {
	 this.data= data;  }
}
class BinaryTree{
	static Node root;

static void add(int data) {

	Node newNode= new Node(data);
	
	if(root== null) {
		root= newNode;  }
	
	else {
		Node focusNode= root;
		Node parent;
		
		while(true) {
			parent= focusNode;
			
			if(data< focusNode.data) { //  smaller data will be at left side
				focusNode= focusNode.left;  // changing focus to left side
				if(focusNode== null) {
					parent.left= newNode;
					return;   }}
				
				else {
					focusNode= focusNode.right;  // changing focus to right side
					if(focusNode== null) {
						parent.right= newNode;
						return;  }}
		}}}


public static boolean isSubtree(Node root, Node subRoot) {
	
if(root== null) {  // If this node is Empty, then no tree is rooted at this Node
		return false;}
	
if(isIdentical(root, subRoot)) {// Check if the "tree rooted at root" is identical to "tree roooted at subRoot"
		return true;}
	
// If not, check for "tree rooted at root.left" and "tree rooted at root.right"
// If either of them returns true, return true
  return isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot); }


public static boolean isIdentical(Node node1, Node node2) {
	
	
	if(node1== null || node2== null) {   // If any of the nodes is null, then both must be null
		return node1== null && node2== null; }
	

  // If both nodes are non-empty, then their values and left and right subtrees must be equal

return node1.data == node2.data && (isIdentical(node1.left, node2.right)) && (isIdentical(node1.right, node2.left));
	
}}


public class SubtreeOfAnotherTree {
public static void main(String[] args) {
BinaryTree tree= new BinaryTree()	;

tree.root=new Node(4);
tree.root.left = new Node(7);
tree.root.right= new Node(9);
tree.root.left.left = new Node(13);
tree.root.left.right= new Node(20);
tree.root.right.left= new Node(23);
tree.root.right.right= new Node(70);


System.out.println(tree.isSubtree(tree.root, tree.root.left));

}}



