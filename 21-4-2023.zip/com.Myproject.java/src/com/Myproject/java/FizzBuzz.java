package com.Myproject.java;
import java.util.*;


public class FizzBuzz {
public static void main(String[] args) {
	
	ArrayList<String> list = new ArrayList<>();
	
list=	(ArrayList<String>) fizzBuzz(6);  // change value here

for(String i: list) {
	System.out.println(i);
}
}

public static List<String> fizzBuzz(int n) {
    
ArrayList<String> list = new ArrayList<>();


	for(int i=1; i<=n; i++) {
		
		String string= String.valueOf(i);
		
		if(i%3==0 && i%5==0) { //  prints "FizzBuzz" if i is divisible by 3 and 5.
			list.add("FizzBuzz");   // add to the list
			continue;}
		
		if (i%3==0) { //  prints "Fizz" if i is divisible by 3.
			list.add("Fizz");  // add to the list
			continue;}
		
		
			if (i%5==0) {  //  prints "buzz" if i is divisible by 5.
				list.add("Buzz");
				continue;}
			
			else {      // when any other number is encountered
				list.add(string);	}  // add that number
	}
	return list;}
}
