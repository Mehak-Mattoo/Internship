package com.java.MyProject;

import java.util.HashSet;
import java.util.Set;

public class ValidNumbers {
public static void main(String[] args) {
	
	
	String phoneNumbers[]= {"987-123-4567", "123 456 7890", "459-06-7890","456-3984-9821", "987-123-4567"};
	
	Set<String>set= new HashSet<>();   // set to avoid duplicate numbers 
	
	for (String s : phoneNumbers) { //add into set
		set.add(s);}
	
	for(String num: set) {
		
		
if(set.contains(num )&& num.length()==12) {//if set has num and num length==12 including - and spaces
			System.out.println( num);}
		
	}
}
}
