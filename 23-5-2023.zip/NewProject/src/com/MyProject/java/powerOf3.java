package com.MyProject.java;

public class powerOf3 {

	public static void main(String[] args) {
		
		
		int num= 27;
		
	System.out.println(	Solution(num));
	}

	private static boolean Solution(double num) {
		
		while(num>0) {  // loop until num is bigger than 0
		if(num%3==2) {
			return false;}
		num/=3;	}  // keep reducing the number
		
		return true;
		

		
		
	}
	}
