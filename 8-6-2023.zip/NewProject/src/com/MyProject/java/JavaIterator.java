package com.MyProject.java;
import java.util.*;

public class JavaIterator {
public static void main(String[] args) {
	
	
	int arr[]= {3,5,8,1,9};
	int  n= arr.length;
	int k=4;
	
	
	 ArrayList<Integer> list = new ArrayList<>();
list=	javaIterator(n, k, arr);

for(int i: list) {
	System.out.print(i+",");
}
	
	
	
	
}
	
static ArrayList <Integer> javaIterator(int n, int k, int[] arr) {
		 
		  
		 ArrayList<Integer> list = new ArrayList<>();
		 for (int i = 0; i < n; i++) {
			list.add(arr[i]);}  // add arr elements into arraylist
		
		 
		 Iterator itr= (Iterator) list.iterator();  // make a iterator
		 
		 while(((java.util.Iterator<Integer>) itr).hasNext()) {  // until there are elemensts left in list
			 int i= (Integer)((java.util.Iterator<Integer>) itr).next();
			 
			 if(i<k)  // if i is less than k remove it from iterator and sort the list finally
		     itr.remove();		 }
		 
		 
		 Collections.sort(list);
	        
	        return list;
	        
		 
		 
	 
}
}
