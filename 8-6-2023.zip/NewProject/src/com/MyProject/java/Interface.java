package com.MyProject.java;


interface in1
{
    void display(int p);
}

class testClass implements in1{
    public void display(int k)    {   
    	
    	
    	 int count=0;
         boolean flag=false;
                  
         
         for(int i=2;i<=k;i++){  // at each loop flages become false
          flag=false;
         
             for(int j=2;j<i;j++){
            	 
             if(i%j==0){  // if there is a prime number turn flag to true and break
             flag=true;
             
             break;}}
             
             if(!flag) // if flag is true, increment count
                 count++;}
         
         
         System.out.println(count);   }}


public class Interface {
public static void main(String[] args) {
	
	testClass t=  new testClass();
	t.display(10);
	
	
}
}
