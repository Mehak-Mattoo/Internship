package com.Myproject.java;
import java.util.HashSet;


public class UILinkedList {   // basic structure of node class
	 
	 Node head; 
	 
	  
	    class Node {
	        int data;
	        Node next;
	        
	        Node(int d) {
	            data = d;
	            next = null;} }

	   
	    
	    void push(int new_data)  {  // adds data
	       
	        Node new_node = new Node(new_data);

	        new_node.next = head;

	        head = new_node;   }
	    
	    
	    void printList()   {  // prints list
	    	
	        Node temp = head;
	        while (temp != null) {
	            System.out.print(temp.data + " ");
	            temp = temp.next;      }  }
	 
	    
	    UILinkedList getIntersection(Node head1, Node head2)   {
	    	
	        HashSet<Integer> hset = new HashSet<>();
	        Node n1 = head1;
	        Node n2 = head2;
	        UILinkedList result = new UILinkedList();
	 
	            while (n1 != null) { 	       
	                hset.add(n1.data);  // add all elements in set
	         
	            n1 = n1.next;
	        }
	 
	   // For every element of list2 present in hset, insert the element into the result
	        while (n2 != null) {
	            if (hset.contains(n2.data)) {
	                result.push(n2.data);	            }
	            n2 = n2.next;	        }
	        
	        return result;	    }
	    
	    
 public static void main(String args[] ) {
	    	
	        UILinkedList llist1 = new UILinkedList();
	        UILinkedList llist2 = new UILinkedList();
	        
	        UILinkedList intersection = new UILinkedList();
	 
	        
	        llist1.push(2);
	        llist1.push(14);
	        llist1.push(1);
	        llist1.push(10);
	 
	       
	        llist2.push(10);
	        llist2.push(21);
	        llist2.push(8);
	 
	        intersection   = intersection.getIntersection(llist1.head,
	                                           llist2.head);
	   
	 
	        System.out.println("\nIntersection List:");
	        intersection.printList();
	        
 
 
 }}