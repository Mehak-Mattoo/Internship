package com.myproject.java;
import java.util.*;


class Node{
	
	Node left, right;
     int  data;

public Node(int data) {
	 this.data= data;  }
}
class BinaryTree{
	static Node root;

static void add(int data) {

	Node newNode= new Node(data);
	
	if(root== null) {
		root= newNode;  }
	
	else {
		Node focusNode= root;
		Node parent;
		
		while(true) {
			parent= focusNode;
			
			if(data< focusNode.data) { //  smaller data will be at left side
				focusNode= focusNode.left;  // changing focus to left side
				if(focusNode== null) {
					parent.left= newNode;
					return;   }}
				
				else {
					focusNode= focusNode.right;  // changing focus to right side
					if(focusNode== null) {
						parent.right= newNode;
						return;  }}
		
	
}}}


static Node buildUtil(int in[], int post[], int inStrt,
        int inEnd)
{

// Base case
if (inStrt > inEnd)
return null;

/* Pick current node from Postorder traversal
using postIndex and decrement postIndex */
int curr = post[index];
Node node = new Node(curr);
(index)--;

/* If this node has no children then return */
if (inStrt == inEnd)
return node;

/* Else find the index of this node in Inorder
traversal */
int iIndex = mp.get(curr);

/* Using index in Inorder traversal, con
left and right subtrees */
node.right = buildUtil(in, post, iIndex + 1, inEnd);
node.left = buildUtil(in, post, inStrt, iIndex - 1);
return node;
}
static HashMap<Integer, Integer> mp
= new HashMap<Integer, Integer>();
static int index;

// This function mainly creates an unordered_map, then
// calls buildTreeUtil()
static Node buildTree(int in[], int post[], int len)
{

// Store indexes of all items so that we
// we can quickly find later
for (int i = 0; i < len; i++)
mp.put(in[i], i);

index = len - 1; // Index in postorder
return buildUtil(in, post, 0, len - 1);
}

/* This function is here just to test */
static void preOrder(Node node)
{
if (node == null)
return;
System.out.printf("%d ", node.data);
preOrder(node.left);
preOrder(node.right);
}}

public class TreeFromPostOrder{
	public static void main(String[] args) {
		BinaryTree tree= new BinaryTree()	;

		
		 int in[] = { 44, 8, 2, 5, 1, 6, 3, 7 };
	        int post[] = { 8, 41, 5, 2, 6, 7, 3, 1 };
	        int n = in.length;
	        Node root = tree.buildTree(in, post, n);
	 
	        tree.preOrder(root);
	}
}

