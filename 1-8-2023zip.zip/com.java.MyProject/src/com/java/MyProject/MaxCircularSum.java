package com.java.MyProject;

public class MaxCircularSum {
public static void main(String[] args) {
	
	
	int arr[] = {10,-3,-4,7,6,5,-1};
	
	System.out.println(circularSubarraySum(arr, arr.length));}


static int circularSubarraySum(int a[], int n) {
    
int max1 = kadane(a, n);

int total = 0;
for(int i=0; i<n; i++){
    total+= a[i];
    a[i]= -a[i];}


int minsum = kadane(a,n);
int max2 = total+ minsum;

if(max2==0)return max1;

return Math.max(max1, max2); }

public static int kadane(int[] a , int n){ // employing kadane algorithm to get the max sum subarray
int maxsum = a[0];
int currsum = a[0];
for(int i=1; i<n; i++){
    currsum= Math.max(currsum+a[i], a[i]);
    maxsum = Math.max(currsum, maxsum);}

return maxsum;}


}
