package com.java.MyProject;

public class STringToInteger {
public static void main(String[] args) {

System.out.println(atoi("87"));

}   
	
	
	static int atoi(String str) {   
       try{  
           return Integer.parseInt(str); //method to convert string to number
       }
       catch (Exception e)
       {
           return -1;
       }  
    }


}
