package com.java.MyProject;

public class NumOfCommomFactors {
public static void main(String[] args) {

	int a = 12, b = 6;
	
	System.out.println(commonFactors(a, b));
	
}
public static int commonFactors(int a, int b) {
    
    int min= Math.min(a,b);
    int count=0;

    for(int i=1; i<= min;i++){  // loop only until min of two nums
        if(a%i == 0&& b%i==0){
            count++;
        }}
return count;
}
}
