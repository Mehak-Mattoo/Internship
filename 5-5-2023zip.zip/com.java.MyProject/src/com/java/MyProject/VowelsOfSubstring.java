package com.java.MyProject;

public class VowelsOfSubstring {
public static void main(String[] args) {
	
	String word = "aba";
	
	System.out.println(countVowels(word));
} 

public static long countVowels(String word) {
	
    long ans=0;
    String vowels="aeiou";
    
    
    int len=word.length();
    
    for (int i=0;i<len;i++)
    {
        char ch=word.charAt(i);
        if (ch=='a'|| ch=='e'||ch=='i'||ch=='o'||ch=='u')  // if vowels are found
        {
            ans+=len-i+(long)(i)*(len-i); // add the length
        }
    }
    return ans;
}
}
