package com.java.MyProject;

public class Convert1DTo2D {
public static void main(String[] args) {

	int  original[] = {1,2,3,4};
	int m = 2, n = 2;
	
}

public static int[][] construct2DArray(int[] original, int m, int n) {
    int newArr[][]= new int[m][n];
	 
	 if (m * n != original.length) {  // if row and columns are less than array length
		 return new int [0][0];}  // return empty 2D array
	 
	 int row=0;
	 int column= 0;
	 
	 for (int i = 0; i < original.length; i++) {  
		 newArr[row][column]= original[i]; // first fill columns
		 column++;
		 
		 if(column== n) {
			 column= 0; // then rows
			 row++; }}
		 		 
	return newArr;	
}

}
