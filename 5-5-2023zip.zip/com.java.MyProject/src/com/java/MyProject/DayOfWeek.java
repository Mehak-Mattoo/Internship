package com.java.MyProject;
import java.time.LocalDate;

public class DayOfWeek {
public static void main(String[] args) {
	
	int day = 31, month = 8, year = 2019;
	
	System.out.println(dayOfTheWeek(day, month, year));
	
}
public static String dayOfTheWeek(int day, int month, int year) {
	
    String[] daysOfWeek = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    
    LocalDate date = LocalDate.of(year, month, day); // gets the date from input value
    
    
    java.time.DayOfWeek dayOfWeek  = date.getDayOfWeek(); // gets the day from date
    
    return daysOfWeek[dayOfWeek.getValue() - 1];  // gets the day from array
}}
