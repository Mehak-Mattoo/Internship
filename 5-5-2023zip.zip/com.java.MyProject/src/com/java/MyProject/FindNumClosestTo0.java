package com.java.MyProject;

public class FindNumClosestTo0 {
public static void main(String[] args) {
	
	int[] nums = {-4,-2,1,4,8};
	
	System.out.println(findClosestNumber(nums));
	
}

	
	 public static int findClosestNumber(int[] nums) {
	        int min= nums[0];
		
		for (int i = 1; i < nums.length; i++) {
			if(Math.abs(nums[i]) <= Math.abs(min)) { // if num is smaller than current min
				
				if(Math.abs(nums[i]) == Math.abs(min)) { // if they are same
					min=  nums[i]; }  // set that to min , works for negative numbers
				
				else {
					min= nums[i]; }}}

					return min;
	    }

}
