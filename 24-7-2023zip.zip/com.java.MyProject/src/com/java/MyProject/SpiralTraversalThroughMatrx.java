package com.java.MyProject;

import java.util.ArrayList;

public class SpiralTraversalThroughMatrx {
	public static void main(String[] args) {
		
		int r = 3, c = 4; 
		int	matrix[][] = {{1, 2, 3, 4},
				           {5, 6, 7, 8},
				           {9, 10, 11, 12}};
		
		ArrayList<Integer>list = new ArrayList<>();
		list= spirallyTraverse(matrix, r, c);
		
		for(int i:list) {
			System.out.print(i+" , ");
		}
	
	}
	
	
	 static ArrayList<Integer> spirallyTraverse(int matrix[][], int r, int c){
		 
			ArrayList<Integer>list = new ArrayList<>();
			
		int leftCol=0, rightCol= c-1;
		int topRow=0, bottomRow= r-1;
		
		
			while(leftCol<=rightCol&& topRow<=bottomRow) {// move until whole matrix is  not printed out
				for(int i=leftCol; i<=rightCol;i++) { // move from left to right
					list.add(matrix[topRow][i]); }
				
				topRow++;
				
				for(int i=topRow; i<=bottomRow;i++) { // top to down
					list.add(matrix[i][rightCol]); }
				
				rightCol--;
				
				  if(topRow>bottomRow) break;
				  
				for(int i=rightCol; i>=leftCol;i--) { // right to left
					list.add(matrix[bottomRow][i]); }
				
				bottomRow--;
				
				  if(leftCol>rightCol) break;
				  
				  for(int i=bottomRow; i>=topRow;i--) { // bottom to up
						list.add(matrix[i][leftCol]); } 
				  leftCol++; }
		
			return list;
			
		 
	 }
}
