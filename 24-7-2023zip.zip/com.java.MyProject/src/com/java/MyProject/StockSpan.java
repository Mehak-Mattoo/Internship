package com.java.MyProject;
import java.util.*;

public class StockSpan {
public static void main(String[] args) {
	
int N = 6;
int price[] = {10, 4 ,5, 90, 120, 8};

int ans[]= calculateSpan(price, N);

for(int i:ans) {
	System.out.print(i+" , ");
}
}

public static int[] calculateSpan(int price[], int n)
{
    int[] s=new int[n];
    Stack<Integer> st= new Stack<Integer>();
    
    s[0]=1; //the first value will be 1 always
    st.push(0);
    
    for(int i=1;i<n;i++){
        while(!st.isEmpty() && price[st.peek()]<=price[i]){ // loop until stack is full and top price is les than array curr price
            st.pop(); 
        }
        if(st.isEmpty()){ // when stack becomes empty move ahead
            s[i]=i+1;
        }
        else{ // put the difference between into ans array
            s[i]=i-st.peek(); }
        st.push(i); }
    
    return s;
}


}
