package com.myproject.java;

public class RemoveCharAtK {
public static void main(String[] args) {
	
	String s= "Minnie";
	
	System.out.println(reduced_String(1, s));
	
}

public static String reduced_String(int k, String s){
	
	char letter = 'A';  // any default value
	StringBuffer ans= new StringBuffer();

	for (int i = 0; i < s.length(); i++) { // get the letter at k position 
		if(i==k) {
			letter= s.charAt(i);}}
			
		for (int j = 0; j < s.length(); j++) {  
						
			if(s.charAt(j)==letter) {// if letter is found, continue
				continue; } 
			
			ans.append(s.charAt(j));} // else append all char into ans
	
	return ans.toString();	

	
}
}
